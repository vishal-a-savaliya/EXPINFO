<?php
 define("HOSTNAME","localhost:3306");
 define("USERNAME","vishvas");
 define("PASSWORD","Vish@l2002");
 define("DBNAME","itemdata");

 $con = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
 ?>